<script>
//    if (jQuery(window).width() < 800) {
//        //Add your javascript for large screens here 
//        
//        jQuery('.mail_sidebar_user_list').on('click', function(){
//            
//            alert('800');
//        });                
//    } else {
//        //Add your javascript for small screens here 
//    }




//$('.mail_sidebar_user_list').click(function(e){
//    
//    $('#message_bar').addClass('hidden');
//    $('#reply_bar').removeClass('hidden');
//    
//    $('.mail_body_list h2').append('hidden');
//    
//    
//    $('.mail_sidebar_user_list').removeClass('selected');
//    $(this).addClass('selected');
//
//    e.preventDefault();
//    var id = $(this).attr('data-id');
//    $.ajax({
//        url: 'my_account/read_mail_first',
//        type: 'post',
//        data: {id:id},
//        dataType: 'text',
//        beforeSend: function(){
//            $('#ajax_respond_read_mail').css( 'opacity', '0.5' );
//        },
//        success: function( data ){
//            $('#ajax_respond_read_mail').html( data ).css( 'opacity', '1' );;
//        },
//    });
//});  
</script>