<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">
            Change Password
        </h3>
    </div>
    <div class="panel-body">
        <div class="row">
            <div class="col-md-6">
                <form>
                    <div class="form-group">
                        <label>Old Password</label>
                        <input type="password" class="form-control" placeholder="Enter your old password">
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" class="form-control"  placeholder="Enter your new password">
                    </div>
                    <div class="form-group">
                        <label>Retype New Password</label>
                        <input type="password" class="form-control" placeholder="Retype your new password">
                    </div>

                    <button type="submit" class="btn btn-primary">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</div>