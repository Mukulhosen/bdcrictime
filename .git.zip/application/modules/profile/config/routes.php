<?php

$route['admin/profile'] = 'profile';
$route['admin/profile/index'] = 'profile/index';
$route['admin/profile/business'] = 'profile/business';
$route['admin/profile/service'] = 'profile/service';
$route['admin/profile/business_update'] = 'profile/business_update';
$route['admin/profile/update'] = 'profile/update';
$route['admin/profile/password'] = 'profile/password';
$route['admin/profile/update_password'] = 'profile/update_password';
$route['admin/profile/profile_service_update'] = 'profile/profile_service_update';


$route['admin/profile/photos'] = 'profile/photos';
$route['admin/profile/update_photos'] = 'profile/update_photos';
$route['admin/profile/videos'] = 'profile/videos';
$route['admin/profile/update_videos'] = 'profile/update_videos';

$route['admin/profile/service_list'] = 'profile/service_list';
$route['admin/profile/my_package'] = 'profile/my_package';

